
import tkinter as tk
from tkinter import messagebox
import requests
import json

# Функция для получения данных из GitHub API
def get_repo_info():
    repo_name = entry.get().strip()
    if not repo_name:
        messagebox.showerror("Ошибка", "Введите имя репозитория!")
        return

    # Формирование URL для API
    url = f"https://api.github.com/repos/{repo_name}"
    try:
        response = requests.get(url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        messagebox.showerror("Ошибка", f"Не удалось получить данные: {e}")
        return

    # Парсинг JSON-данных
    data = response.json()
    result = {
        "company": data.get("owner", {}).get("company"),
        "created_at": data.get("created_at"),
        "email": data.get("owner", {}).get("email"),
        "id": data.get("id"),
        "name": data.get("name"),
        "url": data.get("owner", {}).get("url"),
    }

    # Сохранение результата в файл
    output_filename = "repo_info.json"
    with open(output_filename, "w") as f:
        json.dump(result, f, indent=4)

    # Сообщение об успешном сохранении
    messagebox.showinfo("Успех", f"Информация сохранена в файл {output_filename}")

# Создание графического интерфейса
root = tk.Tk()
root.title("GitHub Repo Info")

# Метка и поле ввода
label = tk.Label(root, text="Введите имя репозитория (owner/repo):")
label.pack(pady=10)
entry = tk.Entry(root, width=40)
entry.pack(pady=5)

# Кнопка для получения информации
button = tk.Button(root, text="Получить информацию", command=get_repo_info)
button.pack(pady=20)

# Запуск приложения
root.mainloop()
